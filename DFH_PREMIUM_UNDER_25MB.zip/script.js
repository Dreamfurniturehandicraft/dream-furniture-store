const WA="918218364238";
const HOME_IMAGES=Array.from({length:17},(_,i)=>`assets/home-${String(i+1).padStart(2,"0")}.jpg`);

function imagePath(i){
  if(i<=100) return `images_batch_1/images/catalogue-${i}.jpg`;
  if(i<=200) return `catalogue-${i}.jpg`;
  return `images_batch_3/images/catalogue-${i}.jpg`;
}

const heroSlider=document.getElementById("heroSlider");
const heroDots=document.getElementById("heroDots");
const progress=document.getElementById("heroProgress");
let heroIndex=0, heroTimer;

HOME_IMAGES.slice(0,6).forEach((src,i)=>{
  const slide=document.createElement("div");
  slide.className="hero-slide"+(i===0?" active":"");
  slide.innerHTML=`<img src="${src}" alt="DFH premium sofa ${i+1}" loading="${i?"lazy":"eager"}">`;
  heroSlider.appendChild(slide);
  const dot=document.createElement("button");
  dot.className=i===0?"active":"";
  dot.onclick=()=>goHero(i);
  heroDots.appendChild(dot);
});
const heroSlides=[...document.querySelectorAll(".hero-slide")];
const heroDotEls=[...heroDots.children];

function goHero(i){
  heroIndex=(i+heroSlides.length)%heroSlides.length;
  heroSlides.forEach((s,n)=>s.classList.toggle("active",n===heroIndex));
  heroDotEls.forEach((d,n)=>d.classList.toggle("active",n===heroIndex));
  progress.style.transition="none";progress.style.width="0";
  requestAnimationFrame(()=>{progress.style.transition="width 3s linear";progress.style.width="100%"});
}
function nextHero(){goHero(heroIndex+1)}
function prevHero(){goHero(heroIndex-1)}
document.getElementById("heroNext").onclick=nextHero;
document.getElementById("heroPrev").onclick=prevHero;
function startHero(){clearInterval(heroTimer);progress.style.transition="width 3s linear";progress.style.width="100%";heroTimer=setInterval(nextHero,3000)}
startHero();
heroSlider.addEventListener("mouseenter",()=>clearInterval(heroTimer));
heroSlider.addEventListener("mouseleave",startHero);

const categories=[
 ["1 Seater",HOME_IMAGES[3],"Single-seat comfort"],
 ["2 Seater",HOME_IMAGES[9],"Compact & elegant"],
 ["3 Seater",HOME_IMAGES[15],"Everyday luxury"],
 ["4 Seater",HOME_IMAGES[0],"Family favourite"],
 ["5 Seater",HOME_IMAGES[1],"Roomy comfort"],
 ["6 Seater",HOME_IMAGES[5],"Statement seating"],
 ["L-Shape",HOME_IMAGES[2],"Corner living"],
 ["Sectional",HOME_IMAGES[7],"Flexible layouts"],
 ["Recliner",HOME_IMAGES[4],"Relax in style"],
 ["Custom",HOME_IMAGES[12],"Made for your room"]
];
const categoryGrid=document.getElementById("categoryGrid");
categories.forEach((c,i)=>{
  const card=document.createElement("article");card.className="category-card reveal";
  card.innerHTML=`<img src="${c[1]}" alt="${c[0]} sofa"><small>0${i+1}</small><b>${c[0]}</b><span>${c[2]}</span>`;
  card.onclick=()=>{document.getElementById("catalogue").scrollIntoView({behavior:"smooth"});document.getElementById("searchInput").value=c[0];renderCatalogue(c[0])};
  categoryGrid.appendChild(card);
});

const featured=[
 ["Signature 4-Seater",HOME_IMAGES[0],"Modern • Statement sofa","From ₹39,990"],
 ["L-Shape Lounge",HOME_IMAGES[1],"Sectional • Family comfort","From ₹54,990"],
 ["Modern Accent",HOME_IMAGES[3],"2-Seater • Premium finish","From ₹24,990"],
 ["Classic Chesterfield",HOME_IMAGES[13],"3-Seater • Timeless","From ₹44,990"],
 ["Boucle Lounge",HOME_IMAGES[11],"Lounge • Soft comfort","From ₹29,990"],
 ["Forest Green",HOME_IMAGES[15],"3-Seater • Rich tone","From ₹34,990"]
];
const ft=document.getElementById("featuredTrack");
featured.forEach((p,i)=>{
  const card=document.createElement("article");card.className="featured-card reveal";
  card.innerHTML=`<div class="featured-img"><img src="${p[1]}" alt="${p[0]}" loading="lazy"></div><div class="featured-info"><small>${p[2]}</small><h3>${p[0]}</h3><p>Custom colour and size options available.</p><div class="price">${p[3]} <em>indicative</em></div></div>`;
  card.onclick=()=>openModal(p[1],p[0],"Indicative starting price — ask DFH for the current quote.");
  ft.appendChild(card);
});
document.getElementById("featuredPrev").onclick=()=>ft.scrollBy({left:-ft.clientWidth*.7,behavior:"smooth"});
document.getElementById("featuredNext").onclick=()=>ft.scrollBy({left:ft.clientWidth*.7,behavior:"smooth"});

const grid=document.getElementById("sofaGrid"), count=document.getElementById("catalogueCount"), loadMore=document.getElementById("loadMore");
let visible=24, query="";
function renderCatalogue(q=""){
  query=(q||"").trim().toLowerCase();
  const arr=[];
  for(let i=1;i<=258;i++){
    const label=`DFH Sofa ${String(i).padStart(3,"0")}`;
    if(!query || label.toLowerCase().includes(query) || "sofa".includes(query)) arr.push(i);
  }
  grid.innerHTML="";
  arr.slice(0,visible).forEach((i,idx)=>{
    const card=document.createElement("article");card.className="sofa-card";card.style.animationDelay=`${(idx%12)*35}ms`;
    card.innerHTML=`<div class="sofa-image"><img src="${imagePath(i)}" alt="${`DFH Sofa ${i}`}" loading="lazy"></div><div class="sofa-info"><small>CATALOGUE ${String(i).padStart(3,"0")}</small><b>DFH Sofa ${i}</b><span>Tap to view • Ask price on WhatsApp</span></div>`;
    card.onclick=()=>openModal(imagePath(i),`DFH Sofa ${i}`,`Catalogue visual ${i} • Price and availability on request.`);
    grid.appendChild(card);
  });
  count.textContent=`${Math.min(visible,arr.length)} of ${arr.length} sofas`;
  loadMore.style.display=visible<arr.length?"flex":"none";
}
loadMore.onclick=()=>{visible+=24;renderCatalogue(query)};
document.getElementById("searchInput").addEventListener("input",e=>{visible=24;renderCatalogue(e.target.value)});
renderCatalogue();

function openModal(src,title,meta){
  document.getElementById("modalImg").src=src;
  document.getElementById("modalTitle").textContent=title;
  document.getElementById("modalMeta").textContent=meta;
  document.getElementById("modalWhatsApp").href=`https://wa.me/${WA}?text=${encodeURIComponent(`Hi DFH, I want details/price for ${title}.`)}`;
  document.getElementById("modal").classList.add("open");
  document.getElementById("modal").setAttribute("aria-hidden","false");
  document.body.style.overflow="hidden";
}
function closeModal(){document.getElementById("modal").classList.remove("open");document.getElementById("modal").setAttribute("aria-hidden","true");document.body.style.overflow=""}
document.getElementById("modalClose").onclick=closeModal;
document.getElementById("modal").onclick=e=>{if(e.target.id==="modal")closeModal()};
document.addEventListener("keydown",e=>{if(e.key==="Escape")closeModal()});

const io=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting)e.target.classList.add("visible")}),{threshold:.12});
document.querySelectorAll(".reveal").forEach(el=>io.observe(el));

const header=document.querySelector(".site-header");
window.addEventListener("scroll",()=>header.classList.toggle("scrolled",scrollY>60));
document.getElementById("menuBtn").onclick=()=>document.getElementById("nav").classList.toggle("open");
document.querySelectorAll(".nav a").forEach(a=>a.onclick=()=>document.getElementById("nav").classList.remove("open"));

document.querySelectorAll(".swatches button").forEach(btn=>btn.onclick=()=>{
  document.querySelectorAll(".swatches button").forEach(b=>b.classList.remove("active"));
  btn.classList.add("active");document.getElementById("colourName").textContent=btn.dataset.colour;
});
document.querySelector('.swatches button[data-colour="Cream"]').classList.add("active");

function formToWhatsApp(form,subject){
  const data=new FormData(form);
  const lines=[subject];
  for(const [k,v] of data.entries()) if(v) lines.push(`${k}: ${v}`);
  window.open(`https://wa.me/${WA}?text=${encodeURIComponent(lines.join("\n"))}`,"_blank");
}
document.getElementById("customForm").addEventListener("submit",e=>{e.preventDefault();formToWhatsApp(e.currentTarget,"DFH Custom Sofa Enquiry")});
document.getElementById("feedbackForm").addEventListener("submit",e=>{e.preventDefault();formToWhatsApp(e.currentTarget,"DFH Customer Feedback")});

// A simple offer clock: 3-hour window from the moment the page opens.
// It is a visual promotion timer, not a claim about a real stock/price deadline.
let offerEnd=Date.now()+3*60*60*1000;
function tickOffer(){
  const left=Math.max(0,offerEnd-Date.now());
  const h=Math.floor(left/3600000),m=Math.floor(left%3600000/60000),s=Math.floor(left%60000/1000);
  const text=[h,m,s].map(x=>String(x).padStart(2,"0")).join(":");
  document.getElementById("offerCountdown").textContent=`OFFER ${text}`;
  document.getElementById("saleClock").textContent=text;
}
tickOffer();setInterval(tickOffer,1000);
